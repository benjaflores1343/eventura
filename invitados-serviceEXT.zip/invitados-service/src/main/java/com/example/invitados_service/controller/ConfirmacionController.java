package com.example.invitados_service.controller;

import com.example.invitados_service.model.Invitado;
import com.example.invitados_service.service.InvitadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;

@RestController
@RequestMapping("/api/confirmacion")
public class ConfirmacionController {

    @Autowired
    private InvitadoService invitadoService;

    @Operation(summary = "Confirma la asistencia y las restricciones alimentarias de un invitado por su ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Asistencia confirmada correctamente"),
        @ApiResponse(responseCode = "404", description = "Invitado no encontrado")
    })
    @PutMapping("/asistencia/{id}")
    public ResponseEntity<?> confirmarAsistencia(@PathVariable Long id,
                                                 @RequestBody ConfirmacionRequest request) {
        Optional<Invitado> invitadoOpt = invitadoService.obtenerPorId(id);
        if (invitadoOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Invitado no encontrado");
        }
        Invitado invitado = invitadoOpt.get();
        invitado.setAsistenciaConfirmada(request.isAsiste());
        invitado.setRestriccionesAlimentarias(request.getRestriccionesAlimentarias());
        invitadoService.registrarInvitado(invitado);
        return new ResponseEntity<>(invitado, HttpStatus.OK);
    }

    public static class ConfirmacionRequest {
        private boolean asiste;
        private String restriccionesAlimentarias;

        public boolean isAsiste() {
            return asiste;
        }

        public void setAsiste(boolean asiste) {
            this.asiste = asiste;
        }

        public String getRestriccionesAlimentarias() {
            return restriccionesAlimentarias;
        }

        public void setRestriccionesAlimentarias(String restriccionesAlimentarias) {
            this.restriccionesAlimentarias = restriccionesAlimentarias;
        }
    }
}
