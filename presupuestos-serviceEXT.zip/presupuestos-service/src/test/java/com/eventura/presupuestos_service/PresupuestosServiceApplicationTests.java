package com.eventura.presupuestos_service;

import com.eventura.presupuestos_service.PresupuestosServiceApplication;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = PresupuestosServiceApplication.class)
class PresupuestosServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
