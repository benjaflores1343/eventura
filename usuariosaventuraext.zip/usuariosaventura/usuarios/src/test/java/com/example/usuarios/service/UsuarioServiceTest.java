package com.example.usuarios.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.example.usuarios.model.Rol;
import com.example.usuarios.model.Usuario;
import com.example.usuarios.repository.RoleRepository;
import com.example.usuarios.repository.UsuarioRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.password.PasswordEncoder;

class UsuarioServiceTest {

    @Mock
    private RoleRepository roleRepository;

    @Mock
    private UsuarioRepository usuarioRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private UsuarioService usuarioService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testObtenerUsuarios() {
        Usuario user1 = new Usuario();
        user1.setUsername("user1");
        Usuario user2 = new Usuario();
        user2.setUsername("user2");

        when(usuarioRepository.findAll()).thenReturn(Arrays.asList(user1, user2));

        List<Usuario> usuarios = usuarioService.obtenerusuarios();

        assertEquals(2, usuarios.size());
        verify(usuarioRepository).findAll();
    }

    @Test
    void testCrearUsuario() {
        Rol rol = new Rol();
        rol.setId(1L);
        rol.setNombre("ADMIN");

        when(roleRepository.findById(1L)).thenReturn(Optional.of(rol));
        when(passwordEncoder.encode("password")).thenReturn("encodedPassword");

        Usuario usuarioGuardado = new Usuario();
        usuarioGuardado.setUsername("user");
        usuarioGuardado.setPassword("encodedPassword");
        usuarioGuardado.setRol(rol);

        when(usuarioRepository.save(any(Usuario.class))).thenReturn(usuarioGuardado);

        Usuario resultado = usuarioService.crearUsuario("user", "password", 1L);

        assertEquals("user", resultado.getUsername());
        assertEquals("encodedPassword", resultado.getPassword());
        assertEquals(rol, resultado.getRol());

        verify(roleRepository).findById(1L);
        verify(passwordEncoder).encode("password");
        verify(usuarioRepository).save(any(Usuario.class));
    }

    @Test
    void testModificarUsuario() {
        Usuario usuarioExistente = new Usuario();
        usuarioExistente.setId(1L);
        usuarioExistente.setUsername("oldUser");

        Rol rolNuevo = new Rol();
        rolNuevo.setId(2L);
        rolNuevo.setNombre("USER");

        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuarioExistente));
        when(roleRepository.findById(2L)).thenReturn(Optional.of(rolNuevo));
        when(usuarioRepository.save(usuarioExistente)).thenReturn(usuarioExistente);

        Usuario resultado = usuarioService.modificarUsuario(1L, "newUser", 2L);

        assertEquals("newUser", resultado.getUsername());
        assertEquals(rolNuevo, resultado.getRol());

        verify(usuarioRepository).findById(1L);
        verify(roleRepository).findById(2L);
        verify(usuarioRepository).save(usuarioExistente);
    }

    @Test
    void testEliminarUsuario() {
        Usuario usuarioExistente = new Usuario();
        usuarioExistente.setId(1L);

        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuarioExistente));
        doNothing().when(usuarioRepository).delete(usuarioExistente);

        usuarioService.eliminarUsuario(1L);

        verify(usuarioRepository).findById(1L);
        verify(usuarioRepository).delete(usuarioExistente);
    }

    @Test
    void testIniciarSesion_Exitoso() {
        Usuario usuarioExistente = new Usuario();
        usuarioExistente.setUsername("user");
        usuarioExistente.setPassword("encodedPassword");

        when(usuarioRepository.findByUsername("user")).thenReturn(usuarioExistente);
        when(passwordEncoder.matches("password", "encodedPassword")).thenReturn(true);

        Usuario resultado = usuarioService.iniciarSesion("user", "password");

        assertEquals(usuarioExistente, resultado);

        verify(usuarioRepository).findByUsername("user");
        verify(passwordEncoder).matches("password", "encodedPassword");
    }

    @Test
    void testIniciarSesion_Fallido() {
        when(usuarioRepository.findByUsername("user")).thenReturn(null);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            usuarioService.iniciarSesion("user", "password");
        });

        assertEquals("Credenciales inválidas", exception.getMessage());

        verify(usuarioRepository).findByUsername("user");
    }
}
