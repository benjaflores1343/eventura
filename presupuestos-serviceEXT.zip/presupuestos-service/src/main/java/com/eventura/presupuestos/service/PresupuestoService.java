package com.eventura.presupuestos.service;

import com.eventura.presupuestos.model.Presupuesto;
import com.eventura.presupuestos.repository.PresupuestoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class PresupuestoService {

    @Autowired
    private PresupuestoRepository presupuestoRepository;

    /**
     * Guarda un presupuesto en la base de datos.
     * @param presupuesto El objeto presupuesto a guardar.
     * @return El presupuesto guardado.
     */
    public Presupuesto guardar(Presupuesto presupuesto) {
        return presupuestoRepository.save(presupuesto);
    }

    /**
     * Lista todos los presupuestos asociados a un evento.
     * @param eventoId ID del evento.
     * @return Lista de presupuestos para el evento.
     */
    public List<Presupuesto> listarPorEvento(Long eventoId) {
        return presupuestoRepository.findByEventoId(eventoId);
    }

    /**
     * Lista los presupuestos asociados a un evento y un usuario específico.
     * @param eventoId ID del evento.
     * @param usuarioId ID del usuario.
     * @return Lista de presupuestos filtrados por evento y usuario.
     */
    public List<Presupuesto> listarPorEventoYUsuario(Long eventoId, Long usuarioId) {
        return presupuestoRepository.findByEventoIdAndUsuarioId(eventoId, usuarioId);
    }

    /**
     * Calcula el total gastado en un evento sumando los montos de los presupuestos.
     * @param eventoId ID del evento.
     * @return Total gastado en el evento.
     */
    public Double totalGastado(Long eventoId) {
        return presupuestoRepository.findByEventoId(eventoId)
            .stream()
            .mapToDouble(Presupuesto::getMonto)
            .sum();
    }

    /**
     * Calcula el total gastado en un evento por un usuario específico.
     * @param eventoId ID del evento.
     * @param usuarioId ID del usuario.
     * @return Total gastado en el evento por el usuario.
     */
    public Double totalGastado(Long eventoId, Long usuarioId) {
        return presupuestoRepository.findByEventoIdAndUsuarioId(eventoId, usuarioId)
            .stream()
            .mapToDouble(Presupuesto::getMonto)
            .sum();
    }
}
