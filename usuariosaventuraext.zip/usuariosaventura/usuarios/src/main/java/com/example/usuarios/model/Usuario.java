package com.example.usuarios.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import io.swagger.v3.oas.annotations.media.Schema;

@Entity
@Table(name = "usuarios")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Modelo que representa un usuario del sistema")
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador único del usuario", example = "1")
    private Long id;

    @Column(nullable = false,unique = true)
    @Schema(description = "Nombre de usuario único", example = "usuario123")
    private String username;

    @Column(nullable = false,length = 60)
    @Schema(description = "Contraseña del usuario (encriptada)", example = "********")
    private String password;


    @ManyToOne//relacion de mucho a uno
    @JoinColumn(name = "rol_id") //se une con id rol
    @JsonIgnoreProperties("user")
    @Schema(description = "Rol asignado al usuario")
    private Rol rol;
    

}
