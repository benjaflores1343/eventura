package com.eventura.serviciotareas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.eventura.serviciotareas", "com.eventura.invitados"})
@EnableJpaRepositories(basePackages = "com.eventura.invitados.repository")
@EntityScan(basePackages = "com.eventura.invitados.model")
public class ServicioTareasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicioTareasApplication.class, args);
	}

}
