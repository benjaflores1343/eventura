package com.example.invitados_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvitadosServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
