# Instrucciones para poner en marcha el proyecto Servicio Tareas

## 1. Crear la base de datos MySQL

Ejecuta el script SQL `create_database.sql` para crear la base de datos necesaria:

```bash
mysql -u root -p < create_database.sql
```

## 2. Configurar credenciales

Verifica que las credenciales en `src/main/resources/application.properties` sean correctas para tu entorno MySQL.

## 3. Iniciar la aplicación

Ejecuta la aplicación con Maven o tu IDE favorito:

```bash
./mvnw spring-boot:run
```

La aplicación arrancará en el puerto 8084.

## 4. Acceder a Swagger UI

Abre en tu navegador la siguiente URL para ver la documentación de la API:

```
http://localhost:8084/swagger-ui.html
```

## 5. Probar la API con curl

Ejemplo para obtener la documentación OpenAPI en formato JSON:

```bash
curl http://localhost:8084/v3/api-docs
```

## Notas

- Asegúrate de que el servidor MySQL esté corriendo y accesible.
- Si tienes problemas con permisos o conexión, revisa la configuración en `application.properties`.
