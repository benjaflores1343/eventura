package com.example.usuarios.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.usuarios.model.Rol;
import com.example.usuarios.model.Usuario;
import com.example.usuarios.service.RoleService;
import com.example.usuarios.service.UsuarioService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.Parameter;

@RestController
@RequestMapping("/api/v1")

public class UsuarioController {

    @Autowired
    private RoleService roleService;

    @Autowired
    private UsuarioService usuarioService;


    @Operation(summary = "Obtener todos los usuarios", description = "Devuelve una lista de todos los usuarios registrados en el sistema.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Lista de usuarios obtenida correctamente"),
        @ApiResponse(responseCode = "204", description = "No hay usuarios registrados")
    })
    @GetMapping("/users")
    public ResponseEntity<CollectionModel<EntityModel<Usuario>>> obtenerTodosUsuarios(){
        List<EntityModel<Usuario>> users = usuarioService.obtenerusuarios().stream()
            .map(user -> EntityModel.of(user,
                linkTo(methodOn(UsuarioController.class).obtenerUsuarioPorId(user.getId())).withSelfRel(),
                linkTo(methodOn(UsuarioController.class).obtenerTodosUsuarios()).withRel("users")))
            .collect(Collectors.toList());

        if(users.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(CollectionModel.of(users,
            linkTo(methodOn(UsuarioController.class).obtenerTodosUsuarios()).withSelfRel()));
    }

    @GetMapping("/users/{id}")
    @Operation(summary = "Obtener usuario por ID", description = "Devuelve un usuario específico identificado por su ID.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Usuario encontrado y devuelto correctamente"),
        @ApiResponse(responseCode = "404", description = "Usuario no encontrado con el ID proporcionado")
    })
    public ResponseEntity<EntityModel<Usuario>> obtenerUsuarioPorId(
        @Parameter(description = "ID del usuario a obtener") @PathVariable Long id) {
        try {
            Usuario user = usuarioService.obtenerusuarios().stream()
                .filter(u -> u.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado con ID: " + id));

            EntityModel<Usuario> resource = EntityModel.of(user,
                linkTo(methodOn(UsuarioController.class).obtenerUsuarioPorId(id)).withSelfRel(),
                linkTo(methodOn(UsuarioController.class).obtenerTodosUsuarios()).withRel("users"));

            return ResponseEntity.ok(resource);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }

    @GetMapping("/roles")
    @Operation(summary = "Obtener todos los roles", description = "Devuelve una lista de todos los roles disponibles en el sistema.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Lista de roles obtenida correctamente"),
        @ApiResponse(responseCode = "204", description = "No hay roles disponibles")
    })
    public ResponseEntity<List<Rol>> obtenerRoles(){
        List<Rol> roles = roleService.obtenerRoles();
        if(roles.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(roles);
    }

    @PostMapping("/roles")
    @Operation(summary = "Crear un nuevo rol", description = "Crea un nuevo rol con el nombre especificado.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Rol creado correctamente"),
        @ApiResponse(responseCode = "400", description = "Nombre de rol inválido o ya existente")
    })
    public ResponseEntity<Rol> crearRol(
        @Parameter(description = "Nombre del nuevo rol") @RequestParam String nombre) {
        try {
            Rol nuevoRol = roleService.createRole(nombre);
            return ResponseEntity.status(HttpStatus.CREATED).body(nuevoRol);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }

    @PostMapping("/users")
    @Operation(summary = "Crear un nuevo usuario", description = "Crea un nuevo usuario con el nombre de usuario, contraseña y rol especificados.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Usuario creado correctamente"),
        @ApiResponse(responseCode = "404", description = "Rol no encontrado o error en la creación del usuario")
    })
    public ResponseEntity<?> crearUsuario(
        @Parameter(description = "Nombre de usuario para el nuevo usuario") @RequestParam String username,
        @Parameter(description = "Contraseña para el nuevo usuario") @RequestParam String password,
        @Parameter(description = "ID del rol asignado al nuevo usuario") @RequestParam Long roleId){
        try {
            Usuario usernuevo = usuarioService.crearUsuario(username, password, roleId);
            EntityModel<Usuario> resource = EntityModel.of(usernuevo,
                linkTo(methodOn(UsuarioController.class).obtenerUsuarioPorId(usernuevo.getId())).withSelfRel(),
                linkTo(methodOn(UsuarioController.class).obtenerTodosUsuarios()).withRel("users"));
            return ResponseEntity.status(HttpStatus.CREATED).body(resource);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @PutMapping("/users/{id}")
    @Operation(summary = "Modificar un usuario existente", description = "Modifica el nombre de usuario y/o el rol de un usuario existente identificado por su ID.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Usuario modificado correctamente"),
        @ApiResponse(responseCode = "404", description = "Usuario no encontrado o error en la modificación")
    })
    public ResponseEntity<?> modificarUsuario(
        @Parameter(description = "ID del usuario a modificar") @PathVariable Long id,
        @Parameter(description = "Nuevo nombre de usuario") @RequestParam String username,
        @Parameter(description = "Nuevo ID de rol (opcional)") @RequestParam(required = false) Long roleId) {
        try {
            Usuario usuarioModificado = usuarioService.modificarUsuario(id, username, roleId);
            return ResponseEntity.ok(usuarioModificado);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @DeleteMapping("/users/{id}")
    @Operation(summary = "Eliminar un usuario", description = "Elimina un usuario identificado por su ID.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Usuario eliminado correctamente"),
        @ApiResponse(responseCode = "404", description = "Usuario no encontrado o error en la eliminación")
    })
    public ResponseEntity<?> eliminarUsuario(
        @Parameter(description = "ID del usuario a eliminar") @PathVariable Long id) {
        try {
            usuarioService.eliminarUsuario(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @PostMapping("/login")
    @Operation(summary = "Iniciar sesión", description = "Permite a un usuario iniciar sesión con su nombre de usuario y contraseña.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Inicio de sesión exitoso"),
        @ApiResponse(responseCode = "401", description = "Credenciales inválidas o error de autenticación")
    })
    public ResponseEntity<?> iniciarSesion(
        @Parameter(description = "Nombre de usuario") @RequestParam String username,
        @Parameter(description = "Contraseña") @RequestParam String password) {
        try {
            Usuario usuario = usuarioService.iniciarSesion(username, password);
            return ResponseEntity.ok(usuario);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
        }
    }
}
