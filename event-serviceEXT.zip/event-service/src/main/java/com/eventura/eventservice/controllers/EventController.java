package com.eventura.eventservice.controllers;

import com.eventura.eventservice.models.Event;
import com.eventura.eventservice.services.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping("/events")
public class EventController {

    @Autowired
    private EventService eventService;

    /**
     * Crea un nuevo evento.
     *
     * @param event El objeto Event que se va a crear.
     * @return ResponseEntity con el evento creado.
     */
    @Operation(summary = "Crear un nuevo evento", description = "Crea un nuevo evento con los datos proporcionados.")
    @PostMapping
    public ResponseEntity<Event> create(@RequestBody Event event) {
        return ResponseEntity.ok(eventService.create(event));
    }

    /**
     * Obtiene una lista de todos los eventos o filtra por usuario si se proporciona usuarioId.
     *
     * @param usuarioId (Opcional) ID del usuario para filtrar eventos.
     * @return Lista de eventos.
     */
    @Operation(summary = "Obtener lista de eventos", description = "Obtiene todos los eventos o filtra por usuario si se proporciona usuarioId.")
    @GetMapping
    public List<Event> getAll(@RequestParam(required = false) Long usuarioId) {
        if (usuarioId != null) {
            return eventService.findByUsuarioId(usuarioId);
        }
        return eventService.findAll();
    }

    /**
     * Obtiene un evento por su ID.
     *
     * @param id ID del evento a buscar.
     * @return ResponseEntity con el evento encontrado o not found si no existe.
     */
    @Operation(summary = "Obtener evento por ID", description = "Obtiene un evento específico por su ID.")
    @GetMapping("/{id}")
    public ResponseEntity<Event> getById(@PathVariable Long id) {
        Event event = eventService.findById(id);
        return event != null ? ResponseEntity.ok(event) : ResponseEntity.notFound().build();
    }

    /**
     * Elimina un evento por su ID.
     *
     * @param id ID del evento a eliminar.
     * @return ResponseEntity sin contenido.
     */
    @Operation(summary = "Eliminar evento por ID", description = "Elimina un evento específico por su ID.")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        eventService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
