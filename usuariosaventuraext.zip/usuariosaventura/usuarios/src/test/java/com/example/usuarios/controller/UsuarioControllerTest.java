package com.example.usuarios.controller;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.Arrays;

import com.example.usuarios.model.Rol;
import com.example.usuarios.model.Usuario;
import com.example.usuarios.service.RoleService;
import com.example.usuarios.service.UsuarioService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

public class UsuarioControllerTest {

    private MockMvc mockMvc;

    @Mock
    private UsuarioService usuarioService;

    @Mock
    private RoleService roleService;

    @InjectMocks
    private UsuarioController usuarioController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(usuarioController).build();
    }

    @Test
    void testObtenerTodosUsuarios() throws Exception {
        Usuario user1 = new Usuario();
        user1.setUsername("user1");
        Usuario user2 = new Usuario();
        user2.setUsername("user2");

        when(usuarioService.obtenerusuarios()).thenReturn(Arrays.asList(user1, user2));

        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/users")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content.length()").value(2))
                .andExpect(jsonPath("$.content[0].username").value("user1"))
                .andExpect(jsonPath("$.content[1].username").value("user2"));

        verify(usuarioService).obtenerusuarios();
    }

    @Test
    void testObtenerTodosUsuarios_NoContent() throws Exception {
        when(usuarioService.obtenerusuarios()).thenReturn(Arrays.asList());

        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/users")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        verify(usuarioService).obtenerusuarios();
    }

    @Test
    void testCrearUsuario() throws Exception {
        Usuario nuevoUsuario = new Usuario();
        nuevoUsuario.setUsername("newuser");

        when(usuarioService.crearUsuario("newuser", "password", 1L)).thenReturn(nuevoUsuario);

        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/users")
                .param("username", "newuser")
                .param("password", "password")
                .param("roleId", "1"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.username").value("newuser"));

        verify(usuarioService).crearUsuario("newuser", "password", 1L);
    }
}
