-- Script para crear la base de datos necesaria para el proyecto

CREATE DATABASE IF NOT EXISTS eventura_invitados;
