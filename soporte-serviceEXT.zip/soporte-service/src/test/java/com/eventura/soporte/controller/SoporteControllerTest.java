package com.eventura.soporte.controller;

import com.eventura.soporte.model.Soporte;
import com.eventura.soporte.service.SoporteService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import com.eventura.soporte_service.SoporteServiceApplication;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(classes = SoporteServiceApplication.class)
@AutoConfigureMockMvc
public class SoporteControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private SoporteService soporteService;

    @Autowired
    private ObjectMapper objectMapper;

    private Soporte soporte1;
    private Soporte soporte2;

    @BeforeEach
    public void setup() {
        soporte1 = new Soporte();
        soporte1.setId(1L);
        soporte1.setEstado("activo");

        soporte2 = new Soporte();
        soporte2.setId(2L);
        soporte2.setEstado("inactivo");
    }

    @Test
    public void testRegistrar() throws Exception {
        Mockito.when(soporteService.guardar(any(Soporte.class))).thenReturn(soporte1);

        mockMvc.perform(post("/api/soporte/registrar")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(soporte1)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(soporte1.getId()))
                .andExpect(jsonPath("$.estado").value(soporte1.getEstado()));
    }

    @Test
    public void testListarPorEvento() throws Exception {
        List<Soporte> lista = Arrays.asList(soporte1, soporte2);
        Mockito.when(soporteService.listarPorEvento(anyLong())).thenReturn(lista);

        mockMvc.perform(get("/api/soporte/evento/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.soporteList", hasSize(2)));
    }

    @Test
    public void testListarPorEventoYUsuario() throws Exception {
        List<Soporte> lista = Arrays.asList(soporte1);
        Mockito.when(soporteService.listarPorEventoYUsuario(anyLong(), anyLong())).thenReturn(lista);

        mockMvc.perform(get("/api/soporte/evento/1")
                .param("usuarioId", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.soporteList", hasSize(1)));
    }

    @Test
    public void testCambiarEstado() throws Exception {
        Mockito.when(soporteService.actualizarEstado(anyLong(), any(String.class))).thenReturn(soporte1);

        mockMvc.perform(put("/api/soporte/estado/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("\"activo\""))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(soporte1.getId()))
                .andExpect(jsonPath("$.estado").value(soporte1.getEstado()));
    }
}
