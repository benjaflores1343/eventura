package com.eventura.soporte.controller;

import com.eventura.soporte.model.Soporte;
import com.eventura.soporte.service.SoporteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/api/soporte")
public class SoporteController {

    @Autowired
    private SoporteService soporteService;

    @Operation(summary = "Registrar un nuevo soporte")
    @PostMapping("/registrar")
    public EntityModel<Soporte> registrar(@RequestBody Soporte soporte) {
        Soporte saved = soporteService.guardar(soporte);
        return EntityModel.of(saved,
                WebMvcLinkBuilder.linkTo(methodOn(SoporteController.class).registrar(soporte)).withSelfRel(),
                WebMvcLinkBuilder.linkTo(methodOn(SoporteController.class).listar(saved.getId(), null)).withRel("listar"));
    }

    @Operation(summary = "Listar soportes por evento y opcionalmente por usuario")
    @GetMapping("/evento/{eventoId}")
    public CollectionModel<EntityModel<Soporte>> listar(
            @Parameter(description = "ID del evento") @PathVariable Long eventoId,
            @Parameter(description = "ID del usuario (opcional)") @RequestParam(required = false) Long usuarioId) {

        List<Soporte> soportes;
        if (usuarioId != null) {
            soportes = soporteService.listarPorEventoYUsuario(eventoId, usuarioId);
        } else {
            soportes = soporteService.listarPorEvento(eventoId);
        }

        List<EntityModel<Soporte>> soporteModels = soportes.stream()
                .map(soporte -> EntityModel.of(soporte,
                        WebMvcLinkBuilder.linkTo(methodOn(SoporteController.class).cambiarEstado(soporte.getId(), null)).withRel("cambiarEstado"),
                        WebMvcLinkBuilder.linkTo(methodOn(SoporteController.class).listar(eventoId, usuarioId)).withSelfRel()))
                .collect(Collectors.toList());

        return CollectionModel.of(soporteModels,
                WebMvcLinkBuilder.linkTo(methodOn(SoporteController.class).listar(eventoId, usuarioId)).withSelfRel());
    }

    @Operation(summary = "Cambiar estado de un soporte")
    @PutMapping("/estado/{id}")
    public EntityModel<Soporte> cambiarEstado(
            @Parameter(description = "ID del soporte") @PathVariable Long id,
            @RequestBody String estado) {
        Soporte updated = soporteService.actualizarEstado(id, estado);
        return EntityModel.of(updated,
                WebMvcLinkBuilder.linkTo(methodOn(SoporteController.class).cambiarEstado(id, estado)).withSelfRel(),
                WebMvcLinkBuilder.linkTo(methodOn(SoporteController.class).listar(id, null)).withRel("listar"));
    }
}
