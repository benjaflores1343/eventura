package com.eventura.tareas_service;

import com.eventura.tareas_service.controller.TareaController;
import com.eventura.tareas_service.model.Tarea;
import com.eventura.tareas_service.service.TareaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class TareaControllerTests {

    @Mock
    private TareaService tareaService;

    @InjectMocks
    private TareaController tareaController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testRegistrarTarea() {
        Tarea tarea = new Tarea();
        tarea.setDescripcion("Nueva tarea");
        tarea.setEventoId(1L);
        tarea.setCompletada(false);

        when(tareaService.guardar(tarea)).thenReturn(tarea);

        EntityModel<Tarea> response = tareaController.registrar(tarea);
        assertNotNull(response);
        assertEquals("Nueva tarea", response.getContent().getDescripcion());
        verify(tareaService, times(1)).guardar(tarea);
    }

    @Test
    public void testRegistrarTareaBadRequest() {
        Tarea tarea = new Tarea();
        tarea.setDescripcion("Tarea inválida");

        when(tareaService.guardar(tarea)).thenThrow(new IllegalArgumentException("Error"));

        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () -> {
            tareaController.registrar(tarea);
        });
        assertEquals(HttpStatus.BAD_REQUEST, exception.getStatusCode());
        verify(tareaService, times(1)).guardar(tarea);
    }

    @Test
    public void testListarPorEvento() {
        Long eventoId = 1L;
        Tarea tarea = new Tarea();
        tarea.setId(1L);
        tarea.setEventoId(eventoId);
        tarea.setDescripcion("Tarea evento");
        tarea.setCompletada(false);

        when(tareaService.listarPorEvento(eventoId)).thenReturn(List.of(tarea));

        CollectionModel<?> response = tareaController.listar(eventoId);
        assertNotNull(response);
        assertFalse(response.getContent().isEmpty());
        verify(tareaService, times(1)).listarPorEvento(eventoId);
    }

    @Test
    public void testCompletarTarea() {
        Long tareaId = 1L;
        Tarea tarea = new Tarea();
        tarea.setId(tareaId);
        tarea.setCompletada(true);

        when(tareaService.marcarComoCompletada(tareaId)).thenReturn(tarea);

        EntityModel<Tarea> response = tareaController.completar(tareaId);
        assertNotNull(response);
        assertTrue(response.getContent().getCompletada());
        verify(tareaService, times(1)).marcarComoCompletada(tareaId);
    }
}
