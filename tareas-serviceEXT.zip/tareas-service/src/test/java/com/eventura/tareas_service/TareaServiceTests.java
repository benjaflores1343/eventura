package com.eventura.tareas_service;

import com.eventura.tareas_service.model.Tarea;
import com.eventura.tareas_service.service.TareaService;
import com.eventura.tareas_service.repository.TareaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;

import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class TareaServiceTests {

    @Mock
    private TareaRepository tareaRepository;

    @InjectMocks
    private TareaService tareaService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGuardarTarea() {
        LocalDate fechaFutura = LocalDate.now().plusDays(1);
        Tarea tarea = new Tarea();
        tarea.setId(1L);
        tarea.setDescripcion("Test tarea");
        tarea.setCompletada(false);
        tarea.setFechaLimite(fechaFutura.toString());

        when(tareaRepository.save(tarea)).thenReturn(tarea);

        Tarea resultado = tareaService.guardar(tarea);
        assertNotNull(resultado);
        assertEquals("Test tarea", resultado.getDescripcion());
        verify(tareaRepository, times(1)).save(tarea);
    }

    @Test
    public void testListarPorEvento() {
        Long eventoId = 1L;
        when(tareaRepository.findByEventoId(eventoId)).thenReturn(List.of(new Tarea()));

        List<Tarea> tareas = tareaService.listarPorEvento(eventoId);
        assertNotNull(tareas);
        verify(tareaRepository, times(1)).findByEventoId(eventoId);
    }

    @Test
    public void testMarcarComoCompletada() {
        Long tareaId = 1L;
        Tarea tarea = new Tarea();
        tarea.setId(tareaId);
        tarea.setCompletada(false);

        when(tareaRepository.findById(tareaId)).thenReturn(Optional.of(tarea));
        when(tareaRepository.save(any(Tarea.class))).thenReturn(tarea);

        Tarea resultado = tareaService.marcarComoCompletada(tareaId);
        assertTrue(resultado.getCompletada());
        verify(tareaRepository, times(1)).findById(tareaId);
        verify(tareaRepository, times(1)).save(tarea);
    }

    @Test
    public void testGuardarTareaFechaLimiteNula() {
        Tarea tarea = new Tarea();
        tarea.setId(2L);
        tarea.setDescripcion("Tarea sin fecha limite");
        tarea.setCompletada(false);
        tarea.setFechaLimite(null);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            tareaService.guardar(tarea);
        });
        assertEquals("La fecha límite no puede ser nula.", exception.getMessage());
    }

    @Test
    public void testGuardarTareaFechaLimiteFormatoInvalido() {
        Tarea tarea = new Tarea();
        tarea.setId(3L);
        tarea.setDescripcion("Tarea con fecha limite invalida");
        tarea.setCompletada(false);
        tarea.setFechaLimite("31-12-2024");

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            tareaService.guardar(tarea);
        });
        assertEquals("Formato de fecha inválido. Use formato ISO yyyy-MM-dd.", exception.getMessage());
    }

    @Test
    public void testGuardarTareaFechaLimitePasada() {
        Tarea tarea = new Tarea();
        tarea.setId(4L);
        tarea.setDescripcion("Tarea con fecha limite pasada");
        tarea.setCompletada(false);
        tarea.setFechaLimite("2000-01-01");

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            tareaService.guardar(tarea);
        });
        assertEquals("La fecha límite no puede ser una fecha pasada.", exception.getMessage());
    }

    @Test
    public void testListarPorEventoConEventoIdNulo() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            tareaService.listarPorEvento(null);
        });
        assertEquals("El ID del evento no puede ser nulo.", exception.getMessage());
    }

    @Test
    public void testListarPorEventoSinTareas() {
        Long eventoId = 999L;
        when(tareaRepository.findByEventoId(eventoId)).thenReturn(List.of());

        List<Tarea> tareas = tareaService.listarPorEvento(eventoId);
        assertNotNull(tareas);
        assertTrue(tareas.isEmpty());
        verify(tareaRepository, times(1)).findByEventoId(eventoId);
    }

    @Test
    public void testMarcarComoCompletadaConIdNoExistente() {
        Long tareaId = 999L;
        when(tareaRepository.findById(tareaId)).thenReturn(Optional.empty());

        Tarea resultado = tareaService.marcarComoCompletada(tareaId);
        assertNull(resultado);
        verify(tareaRepository, times(1)).findById(tareaId);
    }
}
