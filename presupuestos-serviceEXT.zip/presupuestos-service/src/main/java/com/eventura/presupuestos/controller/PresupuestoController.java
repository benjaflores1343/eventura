package com.eventura.presupuestos.controller;

import com.eventura.presupuestos.model.Presupuesto;
import com.eventura.presupuestos.service.PresupuestoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/presupuestos")
@Tag(name = "Presupuesto Controller", description = "API endpoints for managing presupuestos")
public class PresupuestoController {

    @Autowired
    private PresupuestoService presupuestoService;

    /**
     * Registra un nuevo presupuesto.
     * @param presupuesto El objeto presupuesto a registrar.
     * @return El presupuesto registrado con enlaces HATEOAS.
     */
    @Operation(summary = "Registrar presupuesto", description = "Registra un nuevo presupuesto en el sistema")
    @PostMapping("/registrar")
    public EntityModel<Presupuesto> registrar(
            @Parameter(description = "Objeto presupuesto a registrar", required = true)
            @RequestBody Presupuesto presupuesto) {
        Presupuesto saved = presupuestoService.guardar(presupuesto);
        return EntityModel.of(saved,
                WebMvcLinkBuilder.linkTo(methodOn(PresupuestoController.class).registrar(presupuesto)).withSelfRel(),
                WebMvcLinkBuilder.linkTo(methodOn(PresupuestoController.class).listar(saved.getEventoId(), null)).withRel("listar"));
    }

    /**
     * Lista los presupuestos de un evento, opcionalmente filtrados por usuario.
     * @param eventoId ID del evento.
     * @param usuarioId (Opcional) ID del usuario para filtrar.
     * @return Colección de presupuestos con enlaces HATEOAS.
     */
    @Operation(summary = "Listar presupuestos por evento", description = "Obtiene la lista de presupuestos para un evento, opcionalmente filtrados por usuario")
    @GetMapping("/evento/{eventoId}")
    public CollectionModel<EntityModel<Presupuesto>> listar(
            @Parameter(description = "ID del evento", required = true)
            @PathVariable Long eventoId,
            @Parameter(description = "ID del usuario para filtrar", required = false)
            @RequestParam(required = false) Long usuarioId) {
        List<Presupuesto> presupuestos;
        if (usuarioId != null) {
            presupuestos = presupuestoService.listarPorEventoYUsuario(eventoId, usuarioId);
        } else {
            presupuestos = presupuestoService.listarPorEvento(eventoId);
        }

        List<EntityModel<Presupuesto>> presupuestoModels = presupuestos.stream()
                .map(p -> EntityModel.of(p,
                        WebMvcLinkBuilder.linkTo(methodOn(PresupuestoController.class).listar(eventoId, usuarioId)).withSelfRel(),
                        WebMvcLinkBuilder.linkTo(methodOn(PresupuestoController.class).total(eventoId, usuarioId)).withRel("total")))
                .collect(Collectors.toList());

        return CollectionModel.of(presupuestoModels,
                WebMvcLinkBuilder.linkTo(methodOn(PresupuestoController.class).listar(eventoId, usuarioId)).withSelfRel());
    }

    /**
     * Obtiene el total gastado en un evento, opcionalmente filtrado por usuario.
     * @param eventoId ID del evento.
     * @param usuarioId (Opcional) ID del usuario para filtrar.
     * @return Total gastado como un valor Double con enlaces HATEOAS.
     */
    @Operation(summary = "Total gastado por evento", description = "Calcula el total gastado en un evento, opcionalmente filtrado por usuario")
    @GetMapping("/total/{eventoId}")
    public EntityModel<Double> total(
            @Parameter(description = "ID del evento", required = true)
            @PathVariable Long eventoId,
            @Parameter(description = "ID del usuario para filtrar", required = false)
            @RequestParam(required = false) Long usuarioId) {
        Double total;
        if (usuarioId != null) {
            total = presupuestoService.totalGastado(eventoId, usuarioId);
        } else {
            total = presupuestoService.totalGastado(eventoId);
        }
        return EntityModel.of(total,
                WebMvcLinkBuilder.linkTo(methodOn(PresupuestoController.class).total(eventoId, usuarioId)).withSelfRel(),
                WebMvcLinkBuilder.linkTo(methodOn(PresupuestoController.class).listar(eventoId, usuarioId)).withRel("listar"));
    }

    /**
     * Modifica un presupuesto existente.
     * @param presupuesto El objeto presupuesto con los datos actualizados.
     * @return El presupuesto modificado con enlaces HATEOAS.
     */
    @Operation(summary = "Modificar presupuesto", description = "Modifica un presupuesto existente en el sistema")
    @PutMapping("/modificar")
    public EntityModel<Presupuesto> modificar(
            @Parameter(description = "Objeto presupuesto con datos actualizados", required = true)
            @RequestBody Presupuesto presupuesto) {
        Presupuesto updated = presupuestoService.guardar(presupuesto);
        return EntityModel.of(updated,
                WebMvcLinkBuilder.linkTo(methodOn(PresupuestoController.class).modificar(presupuesto)).withSelfRel(),
                WebMvcLinkBuilder.linkTo(methodOn(PresupuestoController.class).listar(updated.getEventoId(), null)).withRel("listar"));
    }
}
