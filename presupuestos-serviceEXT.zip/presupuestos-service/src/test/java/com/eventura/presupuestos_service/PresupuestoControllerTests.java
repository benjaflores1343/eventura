package com.eventura.presupuestos_service;

import com.eventura.presupuestos.controller.PresupuestoController;
import com.eventura.presupuestos.model.Presupuesto;
import com.eventura.presupuestos.service.PresupuestoService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(classes = com.eventura.presupuestos_service.PresupuestosServiceApplication.class)
@AutoConfigureMockMvc
public class PresupuestoControllerTests {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PresupuestoService presupuestoService;

    @Test
    public void testRegistrar() throws Exception {
        Presupuesto presupuesto = new Presupuesto();
        presupuesto.setId(1L);
        presupuesto.setEventoId(1L);
        presupuesto.setDescripcion("Test presupuesto");

        when(presupuestoService.guardar(any(Presupuesto.class))).thenReturn(presupuesto);

        mockMvc.perform(post("/api/presupuestos/registrar")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"eventoId\":1,\"descripcion\":\"Test presupuesto\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.descripcion").value("Test presupuesto"));
    }

    @Test
    public void testListar() throws Exception {
        Presupuesto p1 = new Presupuesto();
        p1.setId(1L);
        p1.setEventoId(1L);
        p1.setDescripcion("Presupuesto 1");

        Presupuesto p2 = new Presupuesto();
        p2.setId(2L);
        p2.setEventoId(1L);
        p2.setDescripcion("Presupuesto 2");

        List<Presupuesto> presupuestos = Arrays.asList(p1, p2);

        when(presupuestoService.listarPorEvento(1L)).thenReturn(presupuestos);

        mockMvc.perform(get("/api/presupuestos/evento/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.presupuestoList[0].id").value(1L))
                .andExpect(jsonPath("$._embedded.presupuestoList[1].id").value(2L));
    }

    @Test
    public void testModificar() throws Exception {
        Presupuesto presupuesto = new Presupuesto();
        presupuesto.setId(1L);
        presupuesto.setEventoId(1L);
        presupuesto.setDescripcion("Presupuesto modificado");

        when(presupuestoService.guardar(any(Presupuesto.class))).thenReturn(presupuesto);

        mockMvc.perform(put("/api/presupuestos/modificar")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"id\":1,\"eventoId\":1,\"descripcion\":\"Presupuesto modificado\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.descripcion").value("Presupuesto modificado"));
    }
}
