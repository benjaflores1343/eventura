package com.eventura.tareas_service.controller;

import com.eventura.tareas_service.model.Tarea;
import com.eventura.tareas_service.service.TareaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.IanaLinkRelations;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

import io.swagger.v3.oas.annotations.Operation;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/tareas")
public class TareaController {

    @Autowired
    private TareaService tareaService;

    @Operation(summary = "Registrar una nueva tarea", description = "Registra una nueva tarea en el sistema con los detalles proporcionados en el cuerpo de la solicitud.")
    @PostMapping("/registrar")
    public EntityModel<Tarea> registrar(@RequestBody Tarea tarea) {
        try {
            Tarea nuevaTarea = tareaService.guardar(tarea);
            return EntityModel.of(nuevaTarea,
                    linkTo(methodOn(TareaController.class).registrar(tarea)).withSelfRel(),
                    linkTo(methodOn(TareaController.class).completar(nuevaTarea.getId())).withRel("completar"),
                    linkTo(methodOn(TareaController.class).listar(nuevaTarea.getEventoId())).withRel("listarPorEvento"));
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
    }

    @Operation(summary = "Listar tareas por evento", description = "Obtiene una lista de tareas asociadas a un evento específico identificado por su ID.")
    @GetMapping("/evento/{eventoId}")
    public CollectionModel<EntityModel<Tarea>> listar(@PathVariable Long eventoId) {
        List<EntityModel<Tarea>> tareas = tareaService.listarPorEvento(eventoId).stream()
                .map(tarea -> EntityModel.of(tarea,
                        linkTo(methodOn(TareaController.class).ver(tarea.getId())).withSelfRel(),
                        linkTo(methodOn(TareaController.class).completar(tarea.getId())).withRel("completar"),
                        linkTo(methodOn(TareaController.class).listar(eventoId)).withRel("listarPorEvento")))
                .collect(Collectors.toList());

        return CollectionModel.of(tareas,
                linkTo(methodOn(TareaController.class).listar(eventoId)).withSelfRel());
    }

    @Operation(summary = "Marcar tarea como completada", description = "Marca una tarea específica como completada utilizando su ID.")
    @PutMapping("/completar/{id}")
    public EntityModel<Tarea> completar(@PathVariable Long id) {
        Tarea tareaCompletada = tareaService.marcarComoCompletada(id);
        return EntityModel.of(tareaCompletada,
                linkTo(methodOn(TareaController.class).completar(id)).withSelfRel(),
                linkTo(methodOn(TareaController.class).listar(tareaCompletada.getEventoId())).withRel("listarPorEvento"));
    }

    @Operation(summary = "Ver detalles de una tarea", description = "Obtiene los detalles de una tarea específica utilizando su ID.")
    @GetMapping("/{id}")
    public EntityModel<Tarea> ver(@PathVariable Long id) {
        Tarea tarea = tareaService.obtenerPorId(id);
        if (tarea == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Tarea no encontrada");
        }
        return EntityModel.of(tarea,
                linkTo(methodOn(TareaController.class).ver(id)).withSelfRel(),
                linkTo(methodOn(TareaController.class).completar(id)).withRel("completar"),
                linkTo(methodOn(TareaController.class).listar(tarea.getEventoId())).withRel("listarPorEvento"));
    }
}
