package com.example.usuarios.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import io.swagger.v3.oas.annotations.media.Schema;

@Entity
@Table(name= "roles")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Modelo que representa un rol de usuario")
public class Rol {

    @Id //identificador primario
    @GeneratedValue(strategy = GenerationType.IDENTITY) //auto incrementa
    @Schema(description = "Identificador único del rol", example = "1")
    private Long id;

    @Column(nullable = false, unique = true, length = 50) //obligatorio, unico y de longitud 50 máximo
    @Schema(description = "Nombre del rol", example = "ADMIN")
    private String nombre;

    //identificar la relacion existente con la tabla

    @OneToMany(mappedBy = "rol", cascade = CascadeType.ALL)
    @JsonIgnore  //no se incluyan los usuarios cuando consulte los roles
    private List<Usuario> users;//lsita porque el pol puede tener mas de un usuario

}
