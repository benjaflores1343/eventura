package com.eventura.invitados.controller;

import com.eventura.invitados.model.Invitado;
import com.eventura.invitados.service.InvitadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/api/invitados")
public class InvitadoController {

    @Autowired
    private InvitadoService invitadoService;

    @Operation(summary = "Registrar un nuevo invitado")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Invitado registrado correctamente"),
        @ApiResponse(responseCode = "400", description = "Solicitud inválida")
    })
    @PostMapping("/registrar")
    public EntityModel<Invitado> registrar(@RequestBody Invitado invitado) {
        Invitado saved = invitadoService.guardar(invitado);
        return EntityModel.of(saved,
                WebMvcLinkBuilder.linkTo(methodOn(InvitadoController.class).registrar(invitado)).withSelfRel(),
                WebMvcLinkBuilder.linkTo(methodOn(InvitadoController.class).listar(saved.getEventoId())).withRel("listar"));
    }

    @Operation(summary = "Listar invitados por ID de evento")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Lista de invitados obtenida correctamente"),
        @ApiResponse(responseCode = "404", description = "Evento no encontrado")
    })
    @GetMapping("/evento/{eventoId}")
    public List<Invitado> listar(@PathVariable Long eventoId) {
        return invitadoService.listarPorEvento(eventoId);
    }

    @Operation(summary = "Confirmar asistencia de un invitado")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Asistencia confirmada correctamente"),
        @ApiResponse(responseCode = "404", description = "Invitado no encontrado")
    })
    @PutMapping("/confirmar/{id}")
    public EntityModel<Invitado> confirmar(@PathVariable Long id) {
        Invitado invitado = invitadoService.confirmarAsistencia(id);
        return EntityModel.of(invitado,
                WebMvcLinkBuilder.linkTo(methodOn(InvitadoController.class).confirmar(id)).withSelfRel(),
                WebMvcLinkBuilder.linkTo(methodOn(InvitadoController.class).listar(invitado.getEventoId())).withRel("listar"));
    }
}
