package com.eventura.eventservice.models;

/**
 * Modelo básico para Usuario, usado en comunicación entre microservicios.
 */
public class Usuario {

    private Long id;
    private String nombre;
    private String email;

    public Usuario() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
